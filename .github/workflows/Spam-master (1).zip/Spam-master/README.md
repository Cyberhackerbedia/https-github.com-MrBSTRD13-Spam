# Spam
$pkg update && pkg upgrade
$pkg install git
$pkg install python python2 bash php
$pip2 install mechanize requests bs4
$pip install mechanize requests bs4
$git clone https://github.com/MrBSTRD13/Spam
$cd Spam
$sh Spam.sh
