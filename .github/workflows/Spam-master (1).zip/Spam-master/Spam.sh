z="
";Gz='E/Sp';Oz='Bomc';Qz='php';Kz='logi';Jz='on2 ';Lz='n.py';Dz='p 2';Mz='c';Az='clea';Nz='php ';Fz='$HOM';Hz='am';Ez='cd /';Pz='all.';Bz='r';Cz='slee';Iz='pyth';
eval "$Az$Bz$z$Cz$Dz$z$Ez$Fz$Gz$Hz$z$Iz$Jz$Kz$Lz$Mz$z$Az$Bz$z$Cz$Dz$z$Ez$Fz$Gz$Hz$z$Nz$Oz$Pz$Qz"